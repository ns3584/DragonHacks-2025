import tensorflow as tf
import numpy as np
from tensorflow.keras.preprocessing import image
import os

# Load the fine-tuned model
model = tf.keras.models.load_model('school_subject_classifier_finetuned_balanced_mobilenetv2.h5')

# Class labels (match your folder names)
class_labels = ['chemistry', 'math', 'physics']

# Function to preprocess and predict a single image
def predict_image(img_path):
    img = image.load_img(img_path, target_size=(224, 224))
    img_array = image.img_to_array(img)
    img_array = np.expand_dims(img_array, axis=0)  # Add batch dimension
    img_array /= 255.0  # Rescale

    predictions = model.predict(img_array)
    predicted_index = np.argmax(predictions, axis=1)[0]
    predicted_label = class_labels[predicted_index]
    confidence = np.max(predictions) * 100

    print(f"Prediction: {predicted_label} ({confidence:.2f}% confidence)")
    return predicted_label, confidence

# Example usage:
# Provide path to a single image you want to test
# test_image_path = 'dataSet\\train\\physics\\Phys1page_230.png'  # ← replace this
# test_image_path = 'dataSet\\train\\chemistry\\Chem1page_35.png'
# test_image_path = 'dataSet\\train\\math\\Algpage_71.png'
# test_image_path = 'dataSet\\validation\\math\\1000035028.jpg'
# test_image_path = 'dataSet\\validation\\chemistry\\1000035059.jpg'
# test_image_path = 'dataSet\\validation\\physics\\1000035038.jpg'
# predict_image(test_image_path)

# Optional: Predict all images in a folder
def predict_folder(folder_path):
    for filename in os.listdir(folder_path):
        if filename.lower().endswith(('.png', '.jpg', '.jpeg')):
            file_path = os.path.join(folder_path, filename)
            print(f"\nTesting {filename}:")
            predict_image(file_path)

# Example usage for folder testing
test_folder = 'dataSet\\validation\\math'
predict_folder(test_folder)
