import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense
from tensorflow.keras.optimizers import Adam

# Paths to your training and validation data
train_dir = 'dataSet\\train'  # Replace with the path to the 'train' folder
val_dir = 'dataSet\\validation'  # Replace with the path to the 'validation' folder

# Image dimensions
image_size = (180, 180)  # Resize images to this size
# image_size = (360, 360)
# 612,792 ?
batch_size = 32

# Image augmentation for training
train_datagen = ImageDataGenerator(
    rescale=1./255,
    rotation_range=40,
    width_shift_range=0.2,
    height_shift_range=0.2,
    shear_range=0.2,
    zoom_range=0.2,
    horizontal_flip=True,
    fill_mode='nearest',
    validation_split=0.2)  # 20% for validation

# Data generators
train_generator = train_datagen.flow_from_directory(
    train_dir,
    target_size=image_size,
    batch_size=batch_size,
    class_mode='categorical',  # Use 'categorical' for multi-class classification
    subset='training')  # Specify 'training' subset

val_generator = train_datagen.flow_from_directory(
    val_dir,
    target_size=image_size,
    batch_size=batch_size,
    class_mode='categorical',  # Use 'categorical' for multi-class classification
    subset='validation')  # Specify 'validation' subset

# Building the CNN model
model = Sequential([
    Conv2D(32, (3, 3), activation='relu', input_shape=(image_size[0], image_size[1], 3)),
    MaxPooling2D(2, 2),
    
    Conv2D(64, (3, 3), activation='relu'),
    MaxPooling2D(2, 2),
    
    Conv2D(128, (3, 3), activation='relu'),
    MaxPooling2D(2, 2),
    
    Flatten(),
    
    Dense(128, activation='relu'),
    Dense(3, activation='softmax')  # 3 classes (Math, Physics, Chemistry)
])

# Compile the model
model.compile(loss='categorical_crossentropy',  # Categorical cross-entropy for multi-class classification
              optimizer=Adam(),
              metrics=['accuracy'])

# Train the model
history = model.fit(
    train_generator,
    epochs=10,  # Adjust number of epochs as needed
    validation_data=val_generator
)

# Save the trained model
model.save('school_subject_classifier.h5')

print("Model training complete and saved as 'school_subject_classifier.h5'.")
