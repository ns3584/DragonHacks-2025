# Load and predict on a new image
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
import numpy as np

# Load model
model = load_model('school_topic_classifier.h5')

# Load an image to predict
img_path = 'path_to_your_image.jpg'
img = image.load_img(img_path, target_size=(IMG_HEIGHT, IMG_WIDTH))
img_array = image.img_to_array(img) / 255.0
img_array = np.expand_dims(img_array, axis=0)

# Predict
predictions = model.predict(img_array)
predicted_class = CLASSES[np.argmax(predictions)]

print(f"The image belongs to: {predicted_class}")
