from pdf2image import convert_from_path
import os

def convert_pdf_to_images(pdf_path, output_folder, dpi=300):
    # Create output folder if it doesn't exist
    os.makedirs(output_folder, exist_ok=True)
    
    # Convert PDF to a list of images
    images = convert_from_path(pdf_path, dpi=dpi)
    
    image_paths = []
    for i, img in enumerate(images):
        img_path = os.path.join(output_folder, f'page_{i+1}.jpg')
        img.save(img_path, 'JPEG')
        image_paths.append(img_path)
    
    print(f"Converted {len(images)} pages into images.")
    return image_paths

# Example Usage
pdf_path = 'Algebra-and-Trigonometry-2e-WEB.pdf'
output_folder = 'dataSet\\math'

image_files = convert_pdf_to_images(pdf_path, output_folder)
