import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.applications import EfficientNetB0
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D, Dropout
from tensorflow.keras.models import Model
from tensorflow.keras.callbacks import EarlyStopping
import numpy as np
import matplotlib.pyplot as plt
import os
import random
from tensorflow.keras.preprocessing.image import load_img, img_to_array

# ---------------------------
# Paths to your dataset
train_dir = 'dataSet\\train'  # Path to 'train' folder
val_dir = 'dataSet\\validation'  # Path to 'validation' folder

# Image size and batch size
IMG_SIZE = (224, 224)
BATCH_SIZE = 32

# Class order (VERY important)
class_names = ['chemistry', 'math', 'physics']

# ---------------------------
# Custom Callback: Stop training when reaching 90% val_accuracy
class TerminateOnBaseline(tf.keras.callbacks.Callback):
    def __init__(self, monitor='val_accuracy', baseline=0.90):
        super(TerminateOnBaseline, self).__init__()
        self.monitor = monitor
        self.baseline = baseline

    def on_epoch_end(self, epoch, logs=None):
        logs = logs or {}
        val = logs.get(self.monitor)
        if val is not None:
            if val >= self.baseline:
                print(f"\nEpoch {epoch}: Reached {self.baseline*100:.1f}% {self.monitor}. Stopping training!")
                self.model.stop_training = True

# ---------------------------
# Custom Balanced Data Generator
def balanced_image_generator(train_dir, class_names, batch_size, img_size):
    # Load first 1000 image paths organized by class
    image_paths = {cls: [] for cls in class_names}
    for cls in class_names:
        folder = os.path.join(train_dir, cls)
        all_filenames = [f for f in os.listdir(folder) if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
        selected_filenames = all_filenames[:1000]  # Only use first 1000
        for filename in selected_filenames:
            image_paths[cls].append(os.path.join(folder, filename))
    
    while True:
        batch_images = []
        batch_labels = []

        for _ in range(batch_size):
            # Randomly pick a class
            selected_class = random.choice(class_names)
            selected_images = image_paths[selected_class]
            
            # Randomly pick an image from that class
            img_path = random.choice(selected_images)
            img = load_img(img_path, target_size=img_size)
            img = img_to_array(img) / 255.0  # Normalize to [0,1]

            label_index = class_names.index(selected_class)
            label = tf.keras.utils.to_categorical(label_index, num_classes=len(class_names))

            batch_images.append(img)
            batch_labels.append(label)

        yield np.array(batch_images), np.array(batch_labels)

# ---------------------------
# Create the generators
train_generator = balanced_image_generator(train_dir, class_names, BATCH_SIZE, IMG_SIZE)

val_datagen = ImageDataGenerator(rescale=1./255)

val_generator = val_datagen.flow_from_directory(
    val_dir,
    target_size=IMG_SIZE,
    batch_size=BATCH_SIZE,
    class_mode='categorical',
    classes=class_names,
    shuffle=False
)

# ---------------------------
# Load base EfficientNetB0 model
base_model = EfficientNetB0(weights='imagenet', include_top=False, input_shape=(224, 224, 3))

# Fine-tune deeper layers
for layer in base_model.layers[:100]:
    layer.trainable = False
for layer in base_model.layers[100:]:
    layer.trainable = True

# Build the model
x = base_model.output
x = GlobalAveragePooling2D()(x)
x = Dropout(0.3)(x)
predictions = Dense(len(class_names), activation='softmax')(x)

model = Model(inputs=base_model.input, outputs=predictions)

# ---------------------------
# Compile the model
model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.0001),
              loss='categorical_crossentropy',
              metrics=['accuracy'])

# ---------------------------
# Callbacks
early_stopping = EarlyStopping(monitor='val_loss', patience=8, restore_best_weights=True)
target_accuracy_callback = TerminateOnBaseline(monitor='val_accuracy', baseline=0.90)

# ---------------------------
# Training
steps_per_epoch = 500
epochs = 50

history = model.fit(
    train_generator,
    steps_per_epoch=steps_per_epoch,
    validation_data=val_generator,
    epochs=epochs,
    callbacks=[early_stopping, target_accuracy_callback]
)

# ---------------------------
# Save the model
model.save('school_subject_classifier_balanced_random_efficientnet.h5')
print("✅ Model training complete and saved.")

# ---------------------------
# Plot training & validation accuracy and loss
plt.figure(figsize=(14,5))

# Accuracy plot
plt.subplot(1,2,1)
plt.plot(history.history['accuracy'], label='Train Accuracy')
plt.plot(history.history['val_accuracy'], label='Val Accuracy')
plt.title('Accuracy Over Epochs')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.legend()

# Loss plot
plt.subplot(1,2,2)
plt.plot(history.history['loss'], label='Train Loss')
plt.plot(history.history['val_loss'], label='Val Loss')
plt.title('Loss Over Epochs')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.legend()

plt.show()
