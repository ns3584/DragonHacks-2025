import tensorflow as tf
from tensorflow.keras.preprocessing import image
import numpy as np
import os

# Load the trained model
model = tf.keras.models.load_model('school_subject_classifier.h5')

# Class labels
class_labels = ['math', 'physics', 'chemistry']

# Function to predict the class of a new image
def predict_subject(image_path):
    # Load the image and resize it to the input size expected by the model
    img = image.load_img(image_path, target_size=(180, 180))  # Ensure the image size matches what the model expects
    
    # Convert the image to a numpy array
    img_array = image.img_to_array(img)
    
    # Rescale the image (as we did during training)
    img_array = img_array / 255.0
    
    # Add batch dimension (since the model expects a batch of images, even if it's just one)
    img_array = np.expand_dims(img_array, axis=0)
    
    # Make the prediction
    prediction = model.predict(img_array)
    
    # Get the predicted class (index of the highest probability)
    predicted_class_index = np.argmax(prediction)
    
    # Return the class label corresponding to the predicted class
    predicted_class = class_labels[predicted_class_index]
    return predicted_class

# Example usage
image_path = 'dataSet\\train\\physics\\Phys1page_31.png'  # Replace with the path to the image you want to classify
predicted_subject = predict_subject(image_path)
print(f"The predicted subject for the image is: {predicted_subject}")
