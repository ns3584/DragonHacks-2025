import fitz  # PyMuPDF

def convert_pdf_to_images(pdf_path, output_folder):
    doc = fitz.open(pdf_path)
    image_paths = []

    for page_num in range(len(doc)):
        page = doc.load_page(page_num)  # Load each page
        pix = page.get_pixmap()         # Render page to a pixmap (image)
        img_path = f"{output_folder}/ChemOrgpage_{page_num + 1}.png"
        pix.save(img_path)
        image_paths.append(img_path)
    
    print(f"Converted {len(doc)} pages into images.")
    return image_paths

# Example usage
pdf_path = 'datasetCreation\\data\\OrganicChemistry-WEB_lNotFqg.pdf'
output_folder = 'dataSet\\train\\chemistry'

image_files = convert_pdf_to_images(pdf_path, output_folder)
