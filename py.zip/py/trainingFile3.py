import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D, Dropout
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint
from tensorflow.keras.applications import MobileNetV2

# Paths to your training and validation data
train_dir = 'dataSet\\train'  # Replace with the path to the 'train' folder
val_dir = 'dataSet\\validation'  # Replace with the path to the 'validation' folder

# Image dimensions
image_size = (224, 224)
batch_size = 32

# Image augmentation for training
train_datagen = ImageDataGenerator(
    rescale=1./255,
    rotation_range=30,
    width_shift_range=0.2,
    height_shift_range=0.2,
    shear_range=0.2,
    zoom_range=0.3,
    horizontal_flip=True,
    fill_mode='nearest')

val_datagen = ImageDataGenerator(rescale=1./255)

# Data generators
train_generator = train_datagen.flow_from_directory(
    train_dir,
    target_size=image_size,
    batch_size=batch_size,
    class_mode='categorical')

val_generator = val_datagen.flow_from_directory(
    val_dir,
    target_size=image_size,
    batch_size=batch_size,
    class_mode='categorical')

# Build the base model
base_model = MobileNetV2(weights='imagenet', include_top=False, input_shape=(image_size[0], image_size[1], 3))

# Freeze all layers initially
base_model.trainable = False

# Add custom layers on top
model = Sequential([
    base_model,
    GlobalAveragePooling2D(),
    Dense(1024, activation='relu'),
    Dropout(0.5),
    Dense(3, activation='softmax')  # 3 classes: Math, Physics, Chemistry
])

# Compile first stage
model.compile(loss='categorical_crossentropy',
              optimizer=tf.keras.optimizers.Adam(learning_rate=0.0001),
              metrics=['accuracy'])

# Train initial (frozen) model
initial_epochs = 10
model.fit(
    train_generator,
    epochs=initial_epochs,
    validation_data=val_generator)

# Fine-tuning stage
# Unfreeze the base model
base_model.trainable = True

# Optionally freeze first few layers and fine-tune deeper layers
fine_tune_at = 100  # Freeze all layers up to layer 100
for layer in base_model.layers[:fine_tune_at]:
    layer.trainable = False

# Re-compile for fine-tuning with a very low learning rate
model.compile(loss='categorical_crossentropy',
              optimizer=tf.keras.optimizers.Adam(learning_rate=1e-5),
              metrics=['accuracy'])

# Callbacks
early_stopping = EarlyStopping(monitor='val_loss', patience=20, restore_best_weights=True)
model_checkpoint = ModelCheckpoint('best_finetuned_model.h5', monitor='val_loss', save_best_only=True)

# Fine-tune the model
fine_tune_epochs = 50
total_epochs = initial_epochs + fine_tune_epochs

history_fine = model.fit(
    train_generator,
    epochs=total_epochs,
    initial_epoch=history_fine.epoch[-1] + 1 if 'history_fine' in locals() else initial_epochs,
    validation_data=val_generator,
    callbacks=[early_stopping, model_checkpoint])

# Save the final model
model.save('school_subject_classifier_finetuned_mobilenetv2.h5')

print("Fine-tuning complete. Final model saved as 'school_subject_classifier_finetuned_mobilenetv2.h5'.")
